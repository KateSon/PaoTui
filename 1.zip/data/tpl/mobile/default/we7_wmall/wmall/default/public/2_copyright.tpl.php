<?php defined('IN_IA') or exit('Access Denied');?><?php  if(!empty($_config_mall['copyright'])) { ?>
    <div class="copyright">
        <?php  echo $_config_mall['copyright'];?>
    </div>
<?php  } ?>
