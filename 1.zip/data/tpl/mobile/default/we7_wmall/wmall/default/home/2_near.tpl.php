<?php defined('IN_IA') or exit('Access Denied');?><?php  include itemplate('public/header', TEMPLATE_INCLUDEPATH);?>
<div class="page">
	<div class="content">
		<div class="infinite-scroll-preloader">
			<div class="preloader"></div>
		</div>
	</div>
</div>
<script type="text/javascript" src="https://webapi.amap.com/maps?v=1.4.1&key=550a3bf0cb6d96c3b43d330fb7d86950"></script>
<script>
$(function(){
	function getLocation() {
		var map, geolocation;
		map = new AMap.Map('allmap');
		map.plugin('AMap.Geolocation', function() {
			geolocation = new AMap.Geolocation({
				enableHighAccuracy: true //是否使用高精度定位，默认:true
			});
			geolocation.getCurrentPosition();
			AMap.event.addListener(geolocation, 'complete', function(data) {
				if(typeof data != 'undefined') {
					var point = data.position;
					var params = {
						lat: point.lat,
						lng: point.lng
					};
				}
				$.post("<?php  echo imurl('wmall/home/near')?>", params, function(data) {
					var result = $.parseJSON(data);
					if(result.message.errno == 0) {
						location.href = result.message.url;
						return false;
					} else {
						$.toast(result.message.message);
						return false;
					}
				});
			});//返回定位信息
			AMap.event.addListener(geolocation, 'error', function(){
				$.toast('获取位置失败', location.href);
				return false;
			});
		});
	}
	getLocation();
});
</script>
<?php  include itemplate('public/footer', TEMPLATE_INCLUDEPATH);?>

