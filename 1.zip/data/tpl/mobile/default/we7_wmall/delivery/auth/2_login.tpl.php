<?php defined('IN_IA') or exit('Access Denied');?><?php  include itemplate('public/header', TEMPLATE_INCLUDEPATH);?>
<div class="page page-auth">
	<div class="content">
		<div class="header">
			<div class="logo">
				<img src="<?php  echo tomedia($config_mall['logo']);?>" alt=""/>
			</div>
			<div class="name"><?php  echo $config_mall['title'];?></div>
		</div>
		<div class="list-block">
			<ul>
				<li>
					<div class="item-content">
						<div class="item-media"><i class="icon icon-phone1"></i></div>
						<div class="item-inner border-1px-b">
							<div class="item-input">
								<input type="number" max="11" name="mobile" placeholder="请输入手机号">
							</div>
						</div>
					</div>
				</li>
				<li>
					<div class="item-content border-1px-b">
						<div class="item-media"><i class="icon icon-lock"></i></div>
						<div class="item-inner">
							<div class="item-input">
								<input type="password" name="password" placeholder="请输入密码">
							</div>
							<a class="item-remark" href="<?php  echo imurl('delivery/auth/forget');?>">
								忘记密码<i class="icon icon-arrow-right"></i>
							</a>
						</div>
					</div>
				</li>
			</ul>
			<div class="content-padded">
				<a href="javascript:;" class="button button-big button-fill button-round button-success button-login">登陆</a>
			</div>
		</div>
		<div class="text hide">
			<p>还没有账号？<a href="<?php  echo imurl('delivery/auth/register');?>">立即注册</a></p>
		</div>
	</div>
</div>
<script>
require(['tiny'], function(tiny){
	var force = "<?php  echo $_GPC['force'];?>";
	$('.button-login').click(function(){
		var $this = $(this);
		if($(this).hasClass('disabled')) {
			return false;
		}
		var mobile = $.trim($('input[name="mobile"]').val());
		if(!mobile) {
			$.toast('请输入手机号');
			return false;
		}
		var reg = /^[01][3456789][0-9]{9}/;
		if(!reg.test(mobile)) {
			$.toast('手机号格式错误');
			return false;
		}
		var password = $.trim($('input[name="password"]').val());
		if(!password) {
			$.toast('请输入密码');
			return false;
		}
		$this.addClass("disabled");
		$.post(tiny.getUrl('delivery/auth/login'), {mobile: mobile, password: password, force: force}, function(data){
			var result = $.parseJSON(data);
			if(!result.message.errno) {
				$.toast('登陆成功', result.message.message);
			} else {
				$.toast(result.message.message);
				$this.removeClass("disabled");
			}
		});
		return false;
	});
});
</script>
<?php  include itemplate('public/footer', TEMPLATE_INCLUDEPATH);?>