<?php defined('IN_IA') or exit('Access Denied');?><div class="second-sidebar-title">
	小程序
</div>
<div class="nav slimscroll">
	<ul class="menu-item">
		<li <?php  if($_W['_ta'] == 'template') { ?>class="active"<?php  } ?>>
			<a href="<?php  echo iurl('store/wxapp/index/template');?>">模板配置</a>
		</li>
		<li <?php  if($_W['_ta'] == 'index') { ?>class="active"<?php  } ?>>
			<a href="<?php  echo iurl('store/wxapp/index/index');?>">页面配置</a>
		</li>
		<li <?php  if($_W['_ta'] == 'cover') { ?>class="active"<?php  } ?>>
			<a href="<?php  echo iurl('store/wxapp/index/cover');?>">链接和二维码</a>
		</li>
	</ul>
</div>
