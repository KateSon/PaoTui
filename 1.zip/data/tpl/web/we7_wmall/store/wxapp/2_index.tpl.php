<?php defined('IN_IA') or exit('Access Denied');?><?php  include itemplate('public/header', TEMPLATE_INCLUDEPATH);?>
<?php  if($ta == 'index') { ?>
<div class="page clearfix">
	<h2>页面设置</h2>
	<form class="form-horizontal form form-validate" id="form1" action="" method="post" enctype="multipart/form-data">
		<div class="alert alert-warning">提醒：页面设置改动后需重新提交微信审核，并且审核通过后才可生效。不填写或者为空,将使用系统默认的</div>
		<?php  if(is_array($extpages)) { foreach($extpages as $page) { ?>
			<div class="form-group">
				<label class="col-xs-12 col-sm-3 col-md-2 control-label"><?php  echo $page['title'];?></label>
				<div class="col-sm-9 col-xs-12">
					<div class="input-group js-colorpicker">
						<span class="input-group-addon">背景颜色</span>
						<input class="form-control" type="text" name="pages[<?php  echo $page['key'];?>][navigationBarBackgroundColor]"  placeholder="背景颜色" value="<?php  echo $config_extpage[$page['key']]['navigationBarBackgroundColor'];?>">
						<span class="input-group-addon" style="width:35px;border-left:none;background-color:<?php  echo $config_extpage[$page['key']]['navigationBarBackgroundColor'];?>"></span>
						<span class="input-group-btn">
							<button class="btn btn-default colorpicker" type="button">选择颜色 <i class="fa fa-caret-down"></i></button>
							<button class="btn btn-default colorclean" type="button"><span><i class="fa fa-remove"></i></span></button>
						</span>
					</div>
				</div>
			</div>
		<?php  } } ?>
		<div class="form-group">
			<div class="col-sm-9 col-xs-9 col-md-9">
				<input type="hidden" name="token" value="<?php  echo $_W['token'];?>">
				<input type="submit" value="提 交" class="btn btn-primary">
			</div>
		</div>
	</form>
</div>
<?php  } ?>

<?php  if($ta == 'cover') { ?>
<div class="page clearfix">
	<form class="form-horizontal form" id="form1" action="" method="post" enctype="multipart/form-data">
		<h3 class="margin-t-0">小程序入口</h3>
		<div class="form-group">
			<label class="col-xs-12 col-sm-3 col-md-2 control-label">直接URL</label>
			<div class="col-sm-9 col-xs-12">
				<p class="form-control-static js-clip" data-text="<?php  echo $urls['wxapp'];?>" title="点击复制">
					<a href="javascript:;"><?php  echo $urls['wxapp'];?></a>
				</p>
			</div>
		</div>
		<div class="form-group">
			<label class="col-xs-12 col-sm-3 col-md-2 control-label">访问二维码</label>
			<?php  if($legel == 1) { ?>
				<div class="col-sm-9 col-xs-12">
					<img src="<?php  echo tomedia($path)?>?t=<?php  echo time();?>" class="qrcode-block" width="150px" height="150px">
					<br>
					<a href="<?php  echo iurl('store/wxapp/index/cover');?>" class="btn btn-primary js-post" style="margin-top: 20px; margin-left: 30px;">重新生成</a>
				</div>
			<?php  } else { ?>
				<div class="col-sm-9 col-xs-12">
					<a href="<?php  echo iurl('store/wxapp/index/cover');?>" class="btn btn-primary js-post">生成小程序店铺二维码</a>
				</div>
			<?php  } ?>
		</div>
	</form>
</div>
<?php  } ?>

<?php  if($ta == 'template') { ?>
<div class="page clearfix">
	<form class="form-horizontal form" id="form1" action="" method="post" enctype="multipart/form-data">
		<h3>模板配置</h3>
		<div class="form-group">
			<label class="col-xs-12 col-sm-3 col-md-2 control-label">商品列表页风格</label>
			<div class="col-sm-9 col-xs-9 col-md-9">
				<a href="<?php  echo iurl('store/wxapp/index/template', array('value' => 1));?>" data-confirm="确定更换模块类型吗" class="js-post thumbnail <?php  if($data == '1' || !$data) { ?>active<?php  } ?>" style="width:200px; float:left; margin-right:20px; border-width: 5px">
					<img src="<?php echo WE7_WMALL_TPL_URL;?>purview/single.png">
				</a>
				<a href="<?php  echo iurl('store/wxapp/index/template', array('value' => 2));?>" data-confirm="确定更换模块类型吗" class="js-post thumbnail <?php  if($data == '2') { ?>active<?php  } ?>" style="width:200px; float:left; margin-right:20px; border-width: 5px">
					<img src="<?php echo WE7_WMALL_TPL_URL;?>purview/double.png">
				</a>
			</div>
		</div>
	</form>
</div>
<?php  } ?>
<?php  include itemplate('public/footer', TEMPLATE_INCLUDEPATH);?>