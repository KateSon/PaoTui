<?php defined('IN_IA') or exit('Access Denied');?><?php  include itemplate('public/header', TEMPLATE_INCLUDEPATH);?>
<?php  if($ta == 'index') { ?>
<form action="" class="form-table">
	<div class="panel panel-table">
		<div class="panel-heading">
			<a href="<?php  echo iurl('store/decoration/shopPage/post');?>" class="btn btn-primary btn-sm">添加海报</a>
		</div>
		<div class="panel-body table-responsive js-table">
			<?php  if(empty($poster)) { ?>
				<div class="no-result">
					<p>还没有相关数据</p>
				</div>
			<?php  } else { ?>
				<table class="table table-hover">
					<thead>
					<tr>
						<th>名称</th>
						<th>图片</th>
						<th class="text-right">操作</th>
					</tr>
					</thead>
					<?php  if(is_array($poster)) { foreach($poster as $index => $item) { ?>
						<tr>
							<td>
								<?php  echo $item['title'];?>
							</td>
							<td><img src="<?php  echo tomedia($item['thumb']);?>" width="50"></td>
							<td class="text-right">
								<a href="<?php  echo iurl('store/decoration/shopPage/post', array('key' => $index))?>" class="btn btn-default btn-sm" title="编辑" data-toggle="tooltip" data-placement="top" ><i class="fa fa-edit"> </i> 编辑</a>
								<a href="<?php  echo iurl('store/decoration/shopPage/del', array('key' => $index))?>" class="btn btn-default btn-sm js-remove" data-confirm="确定删除该海报?"><i class="fa fa-times"> </i> 删除</a>
							</td>
						</tr>
					<?php  } } ?>
				</table>
			<?php  } ?>
		</div>
	</div>
</form>
<?php  } ?>

<?php  if($ta == 'post') { ?>
<div class="page clearfix">
	<h2>编辑海报</h2>
	<form class="form-horizontal form form-validate" id="form-bargain-post" style="max-width: 100%" id="form1" action="" method="post" enctype="multipart/form-data">
		<input type="hidden" name="key" value="<?php  echo $key;?>">
		<div class="form-group">
			<label class="col-xs-12 col-sm-3 col-md-2 control-label">名称</label>
			<div class="col-sm-6 col-xs-6">
				<input type="text" class="form-control" name="title" value="<?php  echo $poster['title'];?>" required="true">
				<span class="help-block">仅用于区分,不在前台显示</span>
			</div>
		</div>
		<div class="form-group">
			<label class="col-xs-12 col-sm-3 col-md-2 control-label">图片</label>
			<div class="col-sm-6 col-xs-6">
				<?php  echo tpl_form_field_image('thumb', $poster['thumb']);?>
				<div class="help-block">建议图片尺寸:640*240</div>
			</div>
		</div>
		<div class="form-group">
			<label class="col-xs-12 col-sm-3 col-md-2 control-label"><span class="require">* </span>关联的商品</label>
			<div class="col-sm-9 col-xs-12 table-responsive">
				<table class="table table-hover table-bordered text-center">
					<thead>
					<tr>
						<th>缩略图</th>
						<th>菜品名称</th>
						<th>价格</th>
						<th>库存</th>
						<th>操作</th>
					</tr>
					</thead>
					<tbody id="goods-container">
					<?php  if(!empty($poster['goods'])) { ?>
					<?php  if(is_array($poster['goods'])) { foreach($poster['goods'] as $item) { ?>
						<tr id="goods-<?php  echo $item['goods_id'];?>">
							<td>
								<input type="hidden" name="goods_id[]" value="<?php  echo $item['id'];?>"/>
								<img src="<?php  echo tomedia($item['thumb']);?>" width="50" alt=""/>
							</td>
							<td><?php  echo $item['title'];?></td>
							<td>￥<?php  echo $item['price'];?></td>
							<td>
								<?php  if($item['total'] == '-1') { ?>
								无限
								<?php  } else { ?>
								<?php  echo $item['total'];?>
								<?php  } ?>
							</td>
							<td>
								<a href="javascript:;" class="btn btn-default btn-goods-item" data-id="<?php  echo $item['id'];?>">删除</a>
							</td>
						</tr>
					<?php  } } ?>
					<?php  } ?>
					</tbody>
					<tfooter>
						<tr>
							<td colspan="10" style="text-align: left">
								<a href="javascript:;" id="btn-select-goods"><i class="fa fa-plus-circle"></i> 选择商品</a>
							</td>
						</tr>
					</tfooter>
				</table>
			</div>
		</div>
		<div class="form-group">
			<div class="col-sm-9 col-xs-9 col-md-9">
				<input type="hidden" name="token" value="<?php  echo $_W['token'];?>">
				<input type="submit" value="提交" class="btn btn-primary">
			</div>
		</div>
	</form>
</div>
<script type="text/html" id="tpl-goods-item">
	<{# for(var i = 0, len = d.length; i < len; i++){ }>
	<tr id="goods-<{d[i].id}>">
		<td>
			<input type="hidden" name="goods_id[]" value="<{d[i].id}>"/>
			<img src="<{d[i].thumb}>" width="50" alt=""/>
		</td>
		<td><{d[i].title}></td>
		<td>￥<{d[i].price}></td>
		<td><{d[i].total}></td>
		<td>
			<a href="javascript:;" class="btn btn-default btn-goods-item" data-id="<{d[i].id}>">删除</a>
		</td>
	</tr>
	<{# } }>
</script>
<script>
	irequire(['tiny','laytpl'], function(tiny,laytpl){
		$('#btn-select-goods').click(function(){
			tiny.selectgoods(function(goods){
				for(var n in goods) {
					if(goods[n]['id']) {
						$('#goods-' + goods[n]['id']).remove();
					}
				}
				var gettpl = $('#tpl-goods-item').html();
				laytpl(gettpl).render(goods, function(html){
					$('#goods-container').append(html);
				});
			}, {mutil: 1, is_options: 0, store_id: "<?php  echo $store['id'];?>"});
		});

		$(document).on('click', '.btn-goods-item', function(){
			$(this).parents('tr').remove();
		});

		$('#form-bargain-post').submit(function(){
			var goods = $('#goods-container tr').size();
			$(this).attr('stop', 0);
			if(!goods) {
				$(this).attr('stop', 1);
				Notify.error('请选择参与活动的商品');
				return false;
			}
			return true;
		});
	});
</script>
<?php  } ?>
<?php  include itemplate('public/footer', TEMPLATE_INCLUDEPATH);?>