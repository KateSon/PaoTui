<?php defined('IN_IA') or exit('Access Denied');?><div class="second-sidebar-title">
	装修
</div>
<div class="nav slimscroll">
	<div class="menu-header">海报</div>
	<ul class="menu-item">
		<li <?php  if($_W['_op'] == 'shopPage') { ?>class="active"<?php  } ?>>
			<a href="<?php  echo iurl('store/decoration/shopPage');?>">商品海报</a>
		</li>
	</ul>
</div>
