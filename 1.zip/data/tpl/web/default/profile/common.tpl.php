<?php defined('IN_IA') or exit('Access Denied');?><div class="we7-page-title">
	参数设置
</div>
<ul class="we7-page-tab">
	<li <?php  if($action == 'passport') { ?> class="active"<?php  } ?>>
		<a href="<?php  echo url('profile/passport')?>">借用权限</a>
	</li>
	<li <?php  if($action == 'tplnotice') { ?> class="active"<?php  } ?>>
		<a href="<?php  echo url('profile/tplnotice')?>">微信通知设置</a>
	</li>
	<li <?php  if($action == 'notify') { ?> class="active"<?php  } ?>>
		<a href="<?php  echo url('profile/notify')?>">邮件通知参数</a>
	</li>
	<li<?php  if($action == 'common' && $do == 'uc_setting') { ?> class="active"<?php  } ?>>
	<a href="<?php  echo url('profile/common/uc_setting')?>">uc站点整合</a>
	</li>
	<li<?php  if($action == 'common' && $do == 'upload_file') { ?> class="active"<?php  } ?>>
	<a href="<?php  echo url('profile/common/upload_file')?>">上传js接口文件</a>
	</li>
	<li<?php  if($action == 'remote') { ?> class="active"<?php  } ?>>
	<a href="<?php  echo url('profile/remote')?>">远程附件</a>
	</li>
</ul>
