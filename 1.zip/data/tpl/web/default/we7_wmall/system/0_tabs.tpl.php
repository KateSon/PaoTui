<?php defined('IN_IA') or exit('Access Denied');?><div class="second-sidebar-title">系统</div>
<div class="nav slimscroll">
	<div class="menu-header">应用管理</div>
	<ul class="menu-item">
		<li <?php  if($_W['_router'] == 'system/plugin/index') { ?>class="active"<?php  } ?>>
			<a href="<?php  echo iurl('system/plugin/index');?>">应用信息</a>
		</li>
		<li <?php  if($_W['_action'] == 'account') { ?>class="active"<?php  } ?>>
			<a href="<?php  echo iurl('system/account/list');?>">公众号权限</a>
		</li>
	</ul>
	<?php  if(!empty($_W['isfounder'])) { ?>
	
	<?php  } ?>
	<div class="menu-header">系统设置</div>
	<ul class="menu-item">
		<li <?php  if($_W['_router'] == 'system/task/') { ?>class="active"<?php  } ?>>
			<a href="<?php  echo iurl('system/task');?>">计划任务</a>
		</li>
	</ul>
	
	<?php  if(!empty($_GPC['s'])) { ?>
		<div class="menu-header">错误日志</div>
		<ul class="menu-item">
			<li <?php  if($_W['_router'] == 'system/slog/config') { ?>class="active"<?php  } ?>>
				<a href="<?php  echo iurl('system/slog/config', array('s' => 1));?>">日志设置</a>
			</li>
		</ul>
	<?php  } ?>
</div>