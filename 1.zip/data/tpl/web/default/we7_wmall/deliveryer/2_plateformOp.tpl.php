<?php defined('IN_IA') or exit('Access Denied');?><?php  if($op == 'changes') { ?>
<form class="form-horizontal form-validate" id="form-changes" action="<?php  echo iurl('deliveryer/plateform/changes');?>" method="post" enctype="multipart/form-data">
	<input type='hidden' name='id' value='<?php  echo $id;?>' />
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button data-dismiss="modal" class="close" type="button">×</button>
				<h4 class="modal-title">账户变动</h4>
			</div>
			<div class="modal-body">
				<div class="form-group">
					<label class="col-xs-12 col-sm-3 col-md-2 control-label">配送员信息</label>
					<div class="col-sm-9 col-xs-12">
						<img width="50" height="50" src="<?php  echo tomedia($deliveryer['avatar'])?>" alt="">
						&nbsp;&nbsp;<span><?php  echo $deliveryer['nickname'];?>/<?php  echo $deliveryer['mobile'];?></span>
					</div>
				</div>
				<div class="form-group">
					<label class="col-xs-12 col-sm-3 col-md-2 control-label">当前余额</label>
					<div class="col-sm-9 col-xs-12"><span><?php  echo $deliveryer['credit2'];?>元</span></div>
				</div>
				<div class="form-group">
					<label class="col-xs-12 col-sm-3 col-md-2 control-label">变动类型</label>
					<div class="col-sm-9 col-xs-12">
						<div class="radio radio-inline">
							<input type="radio" value="1" name="change_type" id="change-type-1" checked>
							<label for="change-type-1">增加</label>
						</div>
						<div class="radio radio-inline">
							<input type="radio" value="2" name="change_type" id="change-type-2">
							<label for="change-type-2">减少</label>
						</div>
						<div class="radio radio-inline">
							<input type="radio" value="3" name="change_type" id="change-type-3">
							<label for="change-type-3">最终余额</label>
						</div>
					</div>
				</div>
				<div class="form-group">
					<label class="col-xs-12 col-sm-3 col-md-2 control-label">变动金额</label>
					<div class="col-sm-9 col-xs-12">
						<input type="number" name="credit2" class="form-control" required="true">
					</div>
				</div>
				<div class="form-group">
					<label class="col-xs-12 col-sm-3 col-md-2 control-label">备注</label>
					<div class="col-sm-9 col-xs-12">
						<textarea name="remark"  class="form-control" required="true"></textarea>
					</div>
				</div>
			</div>
			<div class="modal-footer">
				<button class="btn btn-primary" type="submit">提交</button>
				<button data-dismiss="modal" class="btn btn-default" type="button">取消</button>
			</div>
		</div>
	</div>
</form>
<?php  } ?>

<?php  if($op == 'cancel') { ?>
<form class="form-horizontal form-validate" id="form-changes" action="<?php  echo iurl('deliveryer/getcash/cancel');?>" method="post" enctype="multipart/form-data">
	<input name="id" type="hidden" value="<?php  echo $id;?>"/>
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button data-dismiss="modal" class="close" type="button">×</button>
				<h4 class="modal-title">申请提现撤销</h4>
			</div>
			<div class="modal-body">
				<div class="form-group">
					<label class="col-xs-12 col-sm-3 col-md-2 control-label">配送员信息</label>
					<div class="col-sm-9 col-xs-12">
						<img width="50" height="50" src="<?php  echo tomedia($deliveryer['avatar'])?>" alt="">
						&nbsp;&nbsp;<span><?php  echo $deliveryer['nickname'];?>/<?php  echo $deliveryer['mobile'];?></span>
					</div>
				</div>
				<div class="form-group">
					<label class="col-xs-12 col-sm-3 col-md-2 control-label">申请时间</label>
					<div class="col-sm-9 col-xs-12">
						<span><?php  echo date('Y-m-d H:i:s', $log['addtime'])?></span>
					</div>
				</div>
				<div class="form-group">
					<label class="col-xs-12 col-sm-3 col-md-2 control-label">订单号</label>
					<div class="col-sm-9 col-xs-12">
						<span><?php  echo $log['trade_no'];?></span>
					</div>
				</div>
				<div class="form-group">
					<label class="col-xs-12 col-sm-3 col-md-2 control-label">撤销金额</label>
					<div class="col-sm-9 col-xs-12">
						<span><?php  echo $log['get_fee'];?>元</span>
					</div>
				</div>
				<div class="form-group">
					<label class="col-xs-12 col-sm-3 col-md-2 control-label">备注</label>
					<div class="col-sm-9 col-xs-12">
						<textarea name="remark"  class="form-control" required="true"></textarea>
					</div>
				</div>
			</div>
			<div class="modal-footer">
				<button class="btn btn-primary" type="submit">提交</button>
				<button data-dismiss="modal" class="btn btn-default" type="button">取消</button>
			</div>
		</div>
	</div>
</form>
<?php  } ?>
<?php  if($op == 'group') { ?>
<form class="form-horizontal form-validate" action="<?php  echo iurl('deliveryer/plateform/group', array('set' => 1));?>" method="post" enctype="multipart/form-data">
	<input type='hidden' name='ids' value='<?php  echo $ids;?>'/>
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button data-dismiss="modal" class="close" type="button">×</button>
				<h4 class="modal-title">批量操作</h4>
			</div>
			<div class="modal-body">
				<div class="alert alert-warning">
					如不进行任何操作,请不要点击提交
				</div>
				<div class="form-group">
					<label class="col-xs-12 col-sm-3 col-md-2 control-label">配送员等级</label>
					<div class="col-sm-9 col-xs-12">
						<select name="groupid" class="form-control">
							<option value="">请选择</option>
							<?php  if(is_array($groups)) { foreach($groups as $item) { ?>
							<option value="<?php  echo $item['id'];?>" ><?php  echo $item['title'];?></option>
							<?php  } } ?>
						</select>
					</div>
				</div>
				<div class="form-group" style="margin-bottom: 0;">
					<label class="col-xs-12 col-sm-3 col-md-2 control-label">配送员权限</label>
					<div class="col-sm-9 col-xs-12">
						<div class="checkbox checkbox-inline">
							<input type="checkbox" name="is_takeout" id="type-takeout" value="1">
							<label for="type-takeout">外卖单</label>
						</div>
						<div class="checkbox checkbox-inline">
							<input type="checkbox" name="is_errander" id="type-errander" value="1">
							<label for="type-errander">跑腿单</label>
						</div>
					</div>
				</div>
			</div>
			<div class="modal-footer">
				<button class="btn btn-primary" type="submit">提交</button>
				<button data-dismiss="modal" class="btn btn-default" type="button">取消</button>
			</div>
		</div>
	</div>
</form>
<?php  } ?>
<?php  if($op = 'agent') { ?>
<form class="form-horizontal form-validate" action="<?php  echo iurl('deliveryer/plateform/agent', array('set' => 1));?>" method="post" enctype="multipart/form-data">
	<input type='hidden' name='ids' value='<?php  echo $ids;?>'/>
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button data-dismiss="modal" class="close" type="button">×</button>
				<h4 class="modal-title">批量操作</h4>
			</div>
			<div class="modal-body">
				<div class="alert alert-warning">
					如不进行任何操作,请不要点击提交
				</div>
				<div class="form-group">
					<label class="col-xs-12 col-sm-3 col-md-2 control-label">代理选择</label>
					<div class="col-sm-9 col-xs-12">
						<select name="agentid" class="form-control">
							<option value="0">请选择</option>
							<?php  if(is_array($agents)) { foreach($agents as $item) { ?>
							<option value="<?php  echo $item['id'];?>" ><?php  echo $item['title'];?></option>
							<?php  } } ?>
						</select>
					</div>
				</div>
			</div>
			<div class="modal-footer">
				<button class="btn btn-primary" type="submit">提交</button>
				<button data-dismiss="modal" class="btn btn-default" type="button">取消</button>
			</div>
		</div>
	</div>
</form>
<?php  } ?>