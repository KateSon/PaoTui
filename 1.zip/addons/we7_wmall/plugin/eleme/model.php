<?php
//dezend by http://www.5kym.cn/
defined('IN_IA') || exit('Access Denied');

?>
