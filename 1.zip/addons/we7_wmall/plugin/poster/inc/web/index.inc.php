<?php
//dezend by http://www.5kym.cn/
defined('IN_IA') || exit('Access Denied');
global $_W;
global $_GPC;
header('location:' . iurl('poster/store/post'));
exit();

?>
